#include "init.h"

int main(void){
	Sys_Init();

	// Read the README in the base directory of this project.
}
